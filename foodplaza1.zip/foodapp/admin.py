from django.contrib import admin
from foodapp.models import Food,Customer,OrderItem,Order,ContactUs,Reservation
# Register your models here.
class Foodadmin(admin.ModelAdmin):
    list_display = ['foodId', 'foodName', 'foodcategory', 'foodDescription', 'foodPrice', 'foodImage']


admin.site.register(Food, Foodadmin)
admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(ContactUs)
admin.site.register(Reservation)