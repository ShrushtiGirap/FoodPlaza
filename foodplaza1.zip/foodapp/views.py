from django.shortcuts import render, redirect
from foodapp.models import Food,Customer, User, Order,OrderItem, Reservation, ContactUs
from foodapp.forms import FoodForm, CustomerForm,CreateUserForm,ReservationForm, ContactusForm, MenusearchForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse
from foodapp.utils import cartData,cookieCart
from django.contrib.auth.models import Group
import json
import pandas as pd
import numpy as np
from matplotlib  import pyplot as plt
from io import BytesIO
import base64
# Create your views here.
def index_view(request):
    return render(request,'foodapp/index.html')

def home_view(request):
    return render(request,'foodapp/home.html')

def menu_view(request):

    form=MenusearchForm(request.POST or None)
    if request.method=='POST':
        food=Food.objects.filter(foodName__icontains=form['foodName'].value())
        context= { 'food':food , 'form':form}
        return render(request,'foodapp/menu.html',context)
    else:
        food=Food.objects.all()
    return render(request,'foodapp/menu.html',{'food':food , 'form':form})


def aboutus_view(request):
    return render(request,'foodapp/aboutus.html')

def reservation_view(request):
    return render(request,'foodapp/reservation.html')

def foodlist_view(request):
    food = Food.objects.all()
    return render(request, 'foodapp/food_list.html', {'food': food})

def addfood_view(request):
    if request.method=='POST':
        form=FoodForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()

            return redirect('/foodlist')
    else:
        form = FoodForm()
    return render(request,'foodapp/addfood.html',{'form':form})

def deletefood(request,foodId):
    food=Food.objects.get(foodId=foodId)
    food.delete()
    return redirect('/foodlist')

def updatefood_view(request,foodId):
    food=Food.objects.get(foodId=foodId)
    if request.method=='POST':
        form=FoodForm(data=request.POST,files=request.FILES,instance=food)
        if form.is_valid():
            form.save()
            return redirect('/foodlist')
    else:
        form=FoodForm(instance=food)
    return render(request,'foodapp/updatefood.html',{'form':form})

def customerlist_view(request):
    customer=Customer.objects.all()
    return render(request,'foodapp/customerlist.html',{'customer':customer})

def signup_view(request):
    if request.user.is_authenticated:
        return redirect('/home')
    else:
        form = CreateUserForm()
        if request.method=='POST':
            form=CreateUserForm(request.POST)
            if form.is_valid():
                user=form.save()
                username = form.cleaned_data.get('username')
                request.session['username']=username
                group = Group.objects.get(name='customer')
                user.groups.add(group)
                messages.success(request, 'Account was created for ' + username)
                return redirect('/login')

    return render(request,'accounts/signup.html',{'form':form})

def customerdetail_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        print(username)
        user = User.objects.get(username=username)
        print(user)
        form = CustomerForm(data=request.POST, files=request.FILES, instance=user)
        if form.is_valid():
            name = request.POST.get('name')
            phone = request.POST.get('phone')
            address = request.POST.get('address')
            gender = request.POST.get('gender')
            image = request.POST.get('image')
            customer = Customer(name=name, phone=phone, address=address, gender=gender, profilepic=image, user=user)
            customer.save()
            # message your infomration saved  login to proceed
            return redirect('/login')
        return render(request,'accounts/customerdetails.html',{'form':form})
def login_view(request):
    if request.user.is_authenticated:
        if request.user.customer:
            return  redirect('/home')
        else:
            return redirect('/customerdetail')
    else:
        if request.method=='POST':
            username=request.POST.get('username')
            password = request.POST.get('password')
            user=authenticate(request,username=username,password=password)
            if user is not None:
                login(request, user)
                return redirect('/home')
            else:
                messages.info(request, 'Username OR password is incorrect')

    return render(request, 'accounts/login.html')

def logout_view(request):
    logout(request)
    return redirect('/login')


def cart(request):
    data = cartData(request)

    cartItems = data['cartItems']
    order = data['order']
    items = data['items']

    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'foodapp/mycart.html',context)


def updateItem(request):
    data = json.loads(request.body,encoding='utf-8')
    foodId = data['foodId']
    action = data['action']
    print('Action:', action)
    print('foodId:', foodId)

    customer = request.user.customer
    food = Food.objects.get(foodId=foodId)
    order, created = Order.objects.get_or_create(customer=customer, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(order=order, food=food)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()


    if orderItem.quantity <= 0:
        orderItem.delete()

    return JsonResponse('Item was added', safe=False)


def profile_view(request):
    user=request.user
    customer=Customer.objects.filter(user=user)
    return render(request,'accounts/profile.html',{'customer':customer})

def profileupdate(request):
    context={}
    customer=Customer.objects.get(user__id=request.user.id)
    context['customer']=customer
    if request.method == 'POST':
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        address=request.POST['address']
        user=User.objects.get(id=request.user.id)
        user.email=email
        user.save()
        customer.name=name
        customer.phone=phone
        customer.address=address
        customer.save()
        if "image" in request.FILES:
            img=request.FILES['image']
            customer.profilepic=img
            customer.save()

    return render(request,'accounts/profileupdate.html',context)

def booktable_view(request):
    if request.method == 'POST':
        form = ReservationForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/booktable')
    else:
        form = ReservationForm()
    return render(request, 'foodapp/booktable.html', {'form': form})

def contactus_view(request):
    if request.method == 'POST':
        form =ContactusForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/contactquery')
    else:
        form = ContactusForm()
    return render(request, 'foodapp/contactus.html', {'form': form})

def booktablelist(request):
    booklist=Reservation.objects.all()
    return render(request,'foodapp/booktablelist.html',{'booklist':booklist})

def contactquerylist(request):
    contactlist=ContactUs.objects.all()
    return render(request,'foodapp/contactquery.html',{'contactlist':contactlist})

def orderlist(request):
    data=cartData(request)
    order=data['order']
    orderitem=OrderItem.objects.all()
    return render(request, 'foodapp/orderlist.html', {'orderitem': orderitem, 'order':order})

def Foodgraph(request):
    flist = Food.objects.all()
    print(flist)
    df = pd.DataFrame.from_records(flist.values_list('foodId','foodName','foodcategory','foodDescription','foodPrice'), columns=['foodId','foodName','foodcategory','foodDescription','foodPrice'])
    print(df)
    foodtypes=df.groupby('foodcategory').sum()['foodPrice']
    print(foodtypes)
    indexes=np.arange(2)

    plt.bar(indexes,foodtypes,color=['r'])
    plt.xticks(indexes,['deserts','maindish'])
    #plt.show()
    data= foodtypes
    buf=BytesIO()
    plt.savefig(buf, format='png', dpi=300);
    image_base642= base64.b64encode(buf.getvalue()).decode('utf-8').replace('\n','')
    bvalues=buf.getvalue()
    print(bvalues)

    olist=OrderItem.objects.all()
    print(olist)
    #df=pd.DataFrame.from_records(olist.values_list(for values in olist))
    #plt.scatter()
    return render(request, 'foodapp/showgraph.html',{'foodtypes': foodtypes, 'image_base64':image_base642})
'''contact us   contactus model//
bookings    booking model//
profile.html  customer    update  costomerform   
admin
foodlist //
orderslist
customerlist//
cuntactQuerylist
bookingslist

user
profile//
cart()//
menu//
contact//
bookings//
home_view()//
about//
login//
signup//'''